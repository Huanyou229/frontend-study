<template>
  <div>
    <h2>Settings</h2>
  </div>
</template>
<script setup lang="ts"></script>

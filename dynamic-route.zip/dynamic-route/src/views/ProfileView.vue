<template>
  <div>
    <h2>User Profile</h2>
  </div>
</template>
<script setup lang="ts"></script>

<template>
  <div>
    <h2>User Settings</h2>
  </div>
</template>
<script setup lang="ts"></script>

//弹框属性类型
export type DialogModel = {
  title: string
  visible: boolean
  height: number
  width: number
}

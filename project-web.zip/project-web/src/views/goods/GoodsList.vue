<template>
    <div>
        <h2>商品信息</h2>
    </div>
</template>

<script setup lang="ts">

</script>

<style scoped></style>
<template>
  <div>
    角色管理
  </div>
</template>

<script setup lang="ts">

</script>

<style scoped></style>
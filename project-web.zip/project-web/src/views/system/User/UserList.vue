<template>
    <div>
        <h2>用户管理</h2>
    </div>
</template>

<script setup lang="ts">

</script>

<style scoped></style>
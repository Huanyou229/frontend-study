<template>
    <div>
        <h2>首页</h2>
    </div>
</template>

<script setup lang="ts">

</script>

<style scoped></style>
<template>
  <div>
    首页
  </div>
</template>

<script setup lang="ts">

</script>

<style scoped></style>
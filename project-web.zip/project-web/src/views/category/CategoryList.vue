<template>
    <div>
        <h2>商品类型</h2>
    </div>
</template>

<script setup lang="ts">

</script>

<style scoped></style>
<template>
    <Collapse></Collapse>
</template>
<script setup lang="ts">
import Collapse from "./Collapse.vue";
</script>
<style scoped lang="scss"></style>